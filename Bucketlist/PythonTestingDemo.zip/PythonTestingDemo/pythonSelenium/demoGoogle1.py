

from selenium.webdriver.common.action_chains import ActionChains
from selenium import webdriver
import undetected_chromedriver as uc
from selenium.webdriver.support.abstract_event_listener import AbstractEventListener
from selenium.webdriver.support.event_firing_webdriver import EventFiringWebDriver
from undetected_chromedriver.webelement import WebElement
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC, expected_conditions
from time import sleep



driver = uc.Chrome(use_subprocess=True)

#-------Login------------
wait = WebDriverWait(driver, 20)

#driver.maximize_window()
driver.get("https://www.google.com//gmail")

wait.until(EC.visibility_of_element_located((By.NAME, 'identifier'))).send_keys("mdsadikalamin@gmail.com\n")
wait.until(EC.visibility_of_element_located((By.NAME, 'password'))).send_keys("Gmail2020#\n")
#-----------------------------


#---------send email---------------
sleep(10)
driver.find_element(by=By.XPATH, value="//div[contains(text(),'Compose')]").click()
sleep(5)
driver.find_element_by_css_selector(".oj div textarea").send_keys("mdsadikalamin@gmail.com")
#subject
driver.find_element_by_css_selector(".aoD.az6 input").send_keys("Testing email")
sleep(5)
#body
driver.find_element_by_css_selector(".Ar.Au div").send_keys("Hello")
sleep(10)
driver.find_element_by_css_selector("tr.btC td:nth-of-type(1) div div:nth-of-type(2)").click()
sleep(20)
#--------------------------------

#----------------create lable/folder---------
element = driver.find_element_by_xpath("//span[@class='CJ']")
action = ActionChains(driver)
action.move_to_element(element).perform()

sleep(10)
driver.find_element_by_xpath("//span[@class='CJ']").click()
sleep(10)
element = driver.find_element_by_xpath("//a[contains(text(),'Create new label')]")
action = ActionChains(driver)
action.move_to_element(element).perform()
sleep(10)

driver.find_element_by_xpath("//a[contains(text(),'Create new label')]").click()
sleep(5)

driver.find_element_by_css_selector(".Kj-JD div:nth-of-type(2) input.xx").send_keys("test1")

sleep(5)
driver.find_element_by_xpath("//button[@name='ok']").click()
sleep(20)
#-----------------------



#--------------move email to folder/lable-------------
checkboxes= driver.find_elements_by_xpath("//div[@role='checkbox']")

for checkbox in checkboxes:
    checkbox.click()

sleep(5)
driver.find_element_by_css_selector("div.T-I.J-J5-Ji.T-I-Js-IF.mA.ns.T-I-ax7.L3").click()

driver.find_element_by_css_selector("div[title='test1']").click()
sleep(20)
#------------------------


#----------delete test1--------------
driver.find_element_by_link_text("Manage labels").click()
sleep(10)

element = driver.find_element_by_xpath("//a[contains(text(),'Program Policies')]")
action = ActionChains(driver)
action.move_to_element(element).perform()
sleep(10)

driver.find_element_by_css_selector("table.cf.alO tr:nth-child(25) td:nth-child(4) span").click()
sleep(10)
#button[name='ok']
driver.find_element_by_css_selector("button[name='ok']").click()
#-----------------------



#------------------------------signout--
driver.find_element_by_css_selector("#gb > div.gb_Md.gb_3d.gb_Sd > div.gb_Wd.gb_Za.gb_Ld.gb_0d > div.gb_Se > div.gb_La.gb_hd.gb_mg.gb_f.gb_Af > div > a > img").click()
sleep(10)
frame = driver.find_element_by_css_selector("#gb > div.gb_Md.gb_3d.gb_Sd > div.gb_Wd.gb_Za.gb_Ld.gb_0d > div:nth-child(3) > iframe")
driver.switch_to.frame(frame)
wait = WebDriverWait(driver,10)
wait.until(expected_conditions.presence_of_element_located((By.CLASS_NAME, "wBFtm")))
driver.find_element_by_xpath("//div[contains(text(),'Sign out')]").click()
#------------------------------------------------------


sleep(10)
driver.quit()